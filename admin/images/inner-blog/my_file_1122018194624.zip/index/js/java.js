function valid()
{
var a=document.getElementById("name").value;
if (a=="")
{
	alert("Enter your name here");
	return false;
}
else{
alert("You are successfully submit your form")
}
}



function psr()
{
	var a=document.getElementById("fname").value;
	if(a=="")
	{
		alert("please Enter Your First Name");
		return false;
	}
	else
	{
		re=/^[A-Za-z]+$/;
		if(!re.test(a))
		{
			alert("Sorry only charecter and white space allowed.");
			document.getElementById("fname").value="";
			document.getElementById("fname").focus();
			return false;
		}
	}



var a2=document.getElementById("lname").value;
	if(a2=="")
	{
		alert("please Enter Your Last Name");
		return false;
	}
	else
	{
		re=/^[A-Za-z]+$/;
		if(!re.test(a2))
		{
			alert("Sorry only charecter and white space allowed.");
			document.getElementById("lname").value="";
			document.getElementById("lname").focus();
			return false;
		}
	}


var b=document.getElementById("user").value;
if(b=="")
{
	alert("Please Enter Email Here.....");
	return false;

}

else
{
	re=/^\w+([\-]?\w+)*@\w+([\-]?\w+)*(\.\w{2,3})+$/;
	if(!b.match(re))
	{
		alert("Sorry Email Format Not Valid.");
		document.getElementById("user").value="";
		document.getElementById("user").focus();
		return false;
	}
}



var c=document.getElementById("pwd").value;
var d=document.getElementById("cpwd").value;
if(c=="")
{
	alert("Please Enter Your Password Here");
	return false;
}
else
{
	if(c==d)
	{
		if(c.length<6)
		{
			alert("Error:Password must contain at least six characters!");
			document.getElementById("pwd").value="";
			document.getElementById("cpwd").value="";
			document.getElementById("pwd").focus();
			return false;
		}
	}
	else
	{
		alert("Error:Password Not Matched!");
		document.getElementById("pwd").value="";
			document.getElementById("cpwd").value="";
			document.getElementById("pwd").focus();
			return false;
	}
}


}
